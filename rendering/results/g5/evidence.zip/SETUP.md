# G5 frozen external run — prepared, not executed

Candidate: 5fdf4ec37896153c93a5337a44663d581bd1b286 (runtime tree 91441e7a3b16d0c291e14a09239b2796aee27cc7).
Only Git and byte/JSON file IO have run. No venv, build, project import, install, HOST test or GPU capture has run here.

`preparation.json` binds the exact Git archive, 269 extracted files, 21 official offline wheels and copied SDK inputs. `file-preflight.json` independently checks 72 Panda manifest entries and 14 bounded feature fixtures. The snapshot deliberately includes build/runtime/assets/tests/tools/examples/G5 docs, excluding publication videos and the unrelated physics source tree. All originals remain untouched.

The only system requirements reused are C:/Python311/python.exe (CPython 3.11), installed MSVC/Windows SDK and CMake. Vulkan headers/link library/glslang/validation layer are copied under sdk/ and SHA-bound. Windows profile/AppData and system DLL search remain normal; TEMP is owned by this run. No package-index fallback.

After explicit assignment of the unique execution slot:

    powershell -NoProfile -ExecutionPolicy Bypass -File ./run-prepared.ps1 -Stage Build
    powershell -NoProfile -ExecutionPolicy Bypass -File ./run-prepared.ps1 -Stage Host
    powershell -NoProfile -ExecutionPolicy Bypass -File ./run-prepared.ps1 -Stage Installed

Use PowerShell 7 (pwsh) instead of powershell where available. Each stage preserves logs and checks fresh actual process entrypoints. Never overwrite a failed attempt. The old snapshots and all original failed evidence remain available. The script itself has not yet been executed.

Build uses a new build-env and pinned offline tools, then creates one source-only wheel in dist/. Host supplies this actual wheel to 15 packaging and 15 feature HOST methods; the former real-wheel skip must run. Installed invokes the frozen G5 driver with a separate new runtime/env, performs dependency-free base proof first, then offline [ibl,textures] and later [sapien] installs in that same runtime env, builds the wheel's installed C++/shaders and runs F0 on all three backends.

Default feature stages, all required (no skips):
1. host — original 6 environment tests, source PNG/UV and HDR conversion from installed modules; SAPIEN absent.
2. uv-native — native 16-block original color chart.
3. ibl-native — original public directional environment and reflections.
4. roughness-native — original 16-block linear-data roughness chart.
5. ray-query-native — original public moving occluder, analytic depth/ID/VALID and actual hardware mode.
6. neutral-native — original public two-method suite, 24 tiny captures on software/hardware × grids2/4/8, two scenes and both displays; new DLL + all12 SPIR-V bound.
7. uv-sapien-raster — reference raster original color chart.
8. roughness-sapien-raster — reference raster original roughness chart.
9. uv-sapien-pt — reference PT original color chart.
10. roughness-sapien-pt — reference PT original roughness chart.
11. ibl-sapien — original directional background and mirror calibration.
12. neutral-sapien — original four real exposures, unchanged HDR/sensors, preserved clipped highlight detail.

Original thresholds and original independent fixture bytes are retained. No source products are copied as oracles. Passed/failed/not_verified are distinct; this full frozen run requests all12 and must not be called complete if any remains unverified.

Future A handoff paths (not created yet):
- interpreter: runtime/env/Scripts/python.exe
- installed package: runtime/env/Lib/site-packages/phymeo_rendering
- new native DLL: runtime/native-build/phymeo_native.dll
- shader directory: runtime/native-build (12 SPIR-V)
- Vulkan validation: sdk/validation
- runtime receipt: runtime/report.json
- feature images/raw/receipts: runtime/captures/features/
- SHA-bound independent example bundle: runtime/feature-fixture/

A must use this interpreter and DLL with native device index1 and reference cuda:0, clearing PYTHONPATH/PYTHONHOME and using -I. Reuse is permitted only after the new installation and build are verified. Hardware shadows retain raster primary visibility; PT sensor channels remain unsupported. Generated media/helper changes after the frozen commit do not alter the bound runtime wheel.
