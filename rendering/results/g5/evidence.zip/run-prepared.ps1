# Prepared only. Invoke only while holding the explicitly assigned project slot.
[CmdletBinding()]
param([Parameter(Mandatory=$true)][ValidateSet('Build','Host','Installed','All')][string]$Stage)
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$manifestPath = Join-Path $root 'preparation.json'
$preparation = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
if ($preparation.commit -ne '5fdf4ec37896153c93a5337a44663d581bd1b286') { throw 'Candidate commit is not frozen G5' }
$source = Join-Path $root 'source'
$logs = Join-Path $root 'execution-logs'
if (-not (Test-Path -LiteralPath $logs)) { New-Item -ItemType Directory -Path $logs | Out-Null }
foreach ($entry in $preparation.source_files) {
    if ((Get-FileHash -LiteralPath (Join-Path $source $entry.file) -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) { throw "Frozen source changed: $($entry.file)" }
}
foreach ($entry in $preparation.wheelhouse) {
    if ((Get-FileHash -LiteralPath $entry.file -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) { throw "Offline wheel changed: $($entry.filename)" }
}
foreach ($entry in $preparation.sdk.files) {
    if ((Get-FileHash -LiteralPath (Join-Path $preparation.sdk.directory $entry.file) -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) { throw "SDK input changed: $($entry.file)" }
}
function Save-Json($Path, $Value) {
    [System.IO.File]::WriteAllText($Path, (($Value | ConvertTo-Json -Depth 12)+[char]10), (New-Object System.Text.UTF8Encoding($false)))
}
function Fresh-Guard($Label) {
    $first = @(Get-CimInstance Win32_Process)
    Start-Sleep -Seconds 1
    $second = @(Get-CimInstance Win32_Process)
    $excluded = @()
    foreach ($node in $second | Where-Object { $_.Name -eq 'MSBuild.exe' -and $_.CommandLine -match '/nodemode:1 /nodeReuse:true' }) {
        $prior = $first | Where-Object ProcessId -eq $node.ProcessId
        $children = @($second | Where-Object ParentProcessId -eq $node.ProcessId)
        if ($prior -and @($second | Where-Object ProcessId -eq $node.ParentProcessId).Count -eq 0 -and
            @($children | Where-Object Name -ne 'conhost.exe').Count -eq 0 -and
            $prior.KernelModeTime -eq $node.KernelModeTime -and $prior.UserModeTime -eq $node.UserModeTime -and
            $prior.ReadTransferCount -eq $node.ReadTransferCount -and $prior.WriteTransferCount -eq $node.WriteTransferCount) {
            $excluded += [ordered]@{pid=$node.ProcessId;before=$prior | Select-Object ProcessId,ParentProcessId,Name,CommandLine,KernelModeTime,UserModeTime,ReadTransferCount,WriteTransferCount;after=$node | Select-Object ProcessId,ParentProcessId,Name,CommandLine,KernelModeTime,UserModeTime,ReadTransferCount,WriteTransferCount;children=@($children | Select-Object ProcessId,Name,CommandLine)}
        }
    }
    $active = @($second | Where-Object { $_.Name -match '^(python(w)?|pytest|uv|cmake|ctest|ninja|msbuild|devenv|sapien|blender|ffmpeg|ffprobe|cl|link|glslang)(\.exe)?$' -and $_.ProcessId -notin @($excluded | ForEach-Object {$_.pid}) } | Select-Object ProcessId,ParentProcessId,Name,CommandLine)
    Save-Json (Join-Path $logs ($Label+'.guard.json')) ([ordered]@{utc=[DateTime]::UtcNow.ToString('o');active_entrypoints=$active;excluded_idle_workers=$excluded})
    if ($active.Count) { throw 'Actual project entrypoint is active; wait without terminating it' }
}
function Invoke-Stage($Label, [string[]]$Command) {
    $log = Join-Path $logs ($Label+'.log')
    if (Test-Path -LiteralPath $log) { throw "Refusing to overwrite an earlier execution: $Label" }
    Fresh-Guard ($Label+'-before')
    $start = [DateTime]::UtcNow
    $arguments = $Command[1..($Command.Count-1)]
    & $Command[0] @arguments *> $log
    $code = $LASTEXITCODE
    Save-Json (Join-Path $logs ($Label+'.json')) ([ordered]@{label=$Label;argv=$Command;cwd=(Get-Location).Path;start_utc=$start.ToString('o');end_utc=[DateTime]::UtcNow.ToString('o');exit_code=$code;log=$log;log_sha256=(Get-FileHash -LiteralPath $log -Algorithm SHA256).Hash.ToLowerInvariant()})
    Fresh-Guard ($Label+'-release')
    if ($code -ne 0) { throw "Stage $Label failed with exit $code; original log retained" }
}
$bootstrap = 'C:/Python311/python.exe'
$buildPython = Join-Path $root 'build-env/Scripts/python.exe'
$dist = Join-Path $root 'dist'
$wheel = Join-Path $dist 'phymeo_rendering-0.1.0a0-py3-none-any.whl'
$runtime = Join-Path $root 'runtime'
$names = @('PYTHONPATH','PYTHONHOME','PYTHONDONTWRITEBYTECODE','PIP_NO_INDEX','PIP_DISABLE_PIP_VERSION_CHECK','PHYMEO_G5_WHEEL','TEMP','TMP','TMPDIR')
$saved = @{}
foreach ($name in $names) { $saved[$name] = [Environment]::GetEnvironmentVariable($name,'Process') }
$temporary = Join-Path $root 'temporary'
if (-not (Test-Path -LiteralPath $temporary)) { New-Item -ItemType Directory -Path $temporary | Out-Null }
try {
    Set-Location -LiteralPath $root
    Remove-Item Env:PYTHONPATH,Env:PYTHONHOME -ErrorAction SilentlyContinue
    $env:PYTHONDONTWRITEBYTECODE='1'; $env:PIP_NO_INDEX='1'; $env:PIP_DISABLE_PIP_VERSION_CHECK='1'
    $env:TEMP=$temporary; $env:TMP=$temporary; $env:TMPDIR=$temporary
    if ($Stage -in @('Build','All')) {
        if ((Test-Path -LiteralPath (Join-Path $root 'build-env')) -or (Test-Path -LiteralPath $dist)) { throw 'Build environment and dist must be new' }
        Invoke-Stage '01-build-venv' @($bootstrap,'-I','-m','venv',(Join-Path $root 'build-env'))
        Invoke-Stage '02-offline-build-tools' @($buildPython,'-I','-m','pip','install','--no-index','--no-deps','--only-binary=:all:','--find-links',(Join-Path $root 'wheelhouse/build'),'-r',(Join-Path $source 'rendering/results/g5/build-requirements.txt'))
        Invoke-Stage '03-build-freeze' @($buildPython,'-I','-m','pip','freeze','--all')
        Invoke-Stage '04-wheel-build' @($buildPython,'-I','-m','build','--wheel','--no-isolation','--outdir',$dist,(Join-Path $source 'rendering'))
    }
    if ($Stage -in @('Host','All')) {
        if (-not (Test-Path -LiteralPath $wheel)) { throw 'Actual built wheel is missing' }
        $env:PHYMEO_G5_WHEEL=$wheel
        $env:PYTHONPATH=(Join-Path $source 'rendering/src')+';'+(Join-Path $source 'rendering/tests')
        Invoke-Stage '05-built-wheel-host' @($bootstrap,'-B','-m','unittest','test_g5_packaging','test_g5_features','-v')
        Remove-Item Env:PYTHONPATH,Env:PHYMEO_G5_WHEEL -ErrorAction SilentlyContinue
    }
    if ($Stage -in @('Installed','All')) {
        if ((Test-Path -LiteralPath $runtime) -or -not (Test-Path -LiteralPath $wheel)) { throw 'Installed work must be new, with a built candidate wheel' }
        Invoke-Stage '06-installed-twelve-features' @($bootstrap,'-I',(Join-Path $source 'rendering/tools/g5_reproduce.py'),
            '--source-root',$source,'--wheel',$wheel,'--wheelhouse',(Join-Path $root 'wheelhouse/runtime'),
            '--work-dir',$runtime,'--feature-smoke','--native-device-index','1','--sapien-device','cuda:0',
            '--validation-layer-path',(Join-Path $root 'sdk/validation'),'--cmake','C:/Program Files/CMake/bin/cmake.exe',
            '--cmake-arg=-G','--cmake-arg=Visual Studio 17 2022','--cmake-arg=-A','--cmake-arg=x64',
            ('--cmake-arg=-DVULKAN_INCLUDE_DIR='+(Join-Path $root 'sdk/include')),
            ('--cmake-arg=-DVULKAN_LIBRARY='+(Join-Path $root 'sdk/vulkan-1.lib')),
            ('--cmake-arg=-DGLSLANG_VALIDATOR='+(Join-Path $root 'sdk/bin/glslang.exe')))
    }
} finally {
    foreach ($name in $names) { [Environment]::SetEnvironmentVariable($name,$saved[$name],'Process') }
}
