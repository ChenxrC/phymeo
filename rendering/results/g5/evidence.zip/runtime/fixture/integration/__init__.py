"""Cross-module rendering tests."""
